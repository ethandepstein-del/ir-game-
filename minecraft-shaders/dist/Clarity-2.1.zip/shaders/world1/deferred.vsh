#version 430 compatibility
#define END
#define NO_SHADOW
#define VSH
#include "/program/deferred.glsl"
