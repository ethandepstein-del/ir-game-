#version 120
#define END
#define NO_SHADOW
#define FSH
#include "/program/deferred.glsl"
