#version 120
#define END
#define NO_SHADOW
#define FSH
#define ATROUS_STEP 2
#include "/program/deferred_atrous.glsl"
