#version 120
#define END
#define NO_SHADOW
#define VSH
#include "/program/gbuffers_skybasic.glsl"
